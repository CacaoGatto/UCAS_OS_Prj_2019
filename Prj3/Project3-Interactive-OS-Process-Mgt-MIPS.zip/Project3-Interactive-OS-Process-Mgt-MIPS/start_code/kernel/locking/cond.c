#include "cond.h"
#include "lock.h"

void do_condition_init(condition_t *condition)
{

}

void do_condition_wait(mutex_lock_t *lock, condition_t *condition)
{

}

void do_condition_signal(condition_t *condition)
{

}

void do_condition_broadcast(condition_t *condition)
{

}